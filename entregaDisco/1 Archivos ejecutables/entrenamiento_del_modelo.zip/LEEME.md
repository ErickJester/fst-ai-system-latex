# Entrenamiento nuevo del modelo por segundo (fst_cnn_seg)

Se reunió el 8-nov-2026. Reunido el 16-nov-2026. Entrenamiento con **11 videos**: los 7 del paquete anterior más 4 de **una sola rata** (`EA-1_3`, `EA-2_4`, `Fluox-1(2)`, `fluox-2(2)`).

## Qué subir a Google Drive

Sube **el contenido de la carpeta `fst\`** a `Mi unidad/fst/` (la ruta que usa el cuaderno `fst_cnn_seg.ipynb`):

```
fst\
  clips_seg\        los 11 .npz (uno por video) y sus *_muestra.jpg
  fst_cnn.py
  fst_cnn_seg.py
```

Los dos `.py` van **directo** en `fst/`, no en una subcarpeta `cnn/`: el cuaderno hace `sys.path.insert(0, CARPETA)` e
importa `fst_cnn` y `fst_cnn_seg` de ahí. Son idénticos a los del pipeline del sistema (`fst_cnn_seg` 0.1.0, red
`fst_cnn` 5.0.0).

Antes de subir, en Drive:

1. **Guarda una copia del modelo actual.** El cuaderno guarda el nuevo como `fst/fst_cnn_seg.pt` y **lo sobrescribe**.
   Renombra el actual a, por ejemplo, `fst_cnn_seg_v1.pt`. (Otra copia está en `D:\proyectos\fst\modelos\`.)
2. **Que `clips_seg` quede con exactamente estos 11 `.npz`.** El entrenamiento lee **todos** los `.npz` de la carpeta:
   si queda alguno viejo o de otro formato, entra al entrenamiento sin avisar. Borra la carpeta `clips_seg` anterior y
   sube esta.

Luego, en Colab (con GPU T4 o A100): corre el cuaderno en orden. La celda 4 (`validar`) da la medida honesta por video; la
celda 5 (`final`) entrena con todo y guarda el modelo.

## Qué trae

| Video | Segundos etiquetados | Especímenes | Nado | Escalamiento | Inmovilidad | Activa | Origen |
|---|---|---|---|---|---|---|---|
| Acu-YBN-2 | 940 | 3 | 415 | 170 | 344 | 11 | modelo actual |
| AcuBN1 | 371 | 1 | 151 | 79 | 139 | 2 | modelo actual |
| AcuBN2 | 1,448 | 4 | 441 | 179 | 826 | 2 | modelo actual |
| acu-yintang1 | 585 | 2 | 285 | 81 | 213 | 6 | modelo actual |
| **Acu-baihui1** | 939 | 3 | 420 | 122 | 349 | 48 | **nuevo** (memoria G:) |
| **AcuYN1** | 1,427 | 4 | 759 | 178 | 467 | 23 | **nuevo** (memoria G:) |
| **IMG_0839** | 1,446 | 4 | 674 | 353 | 380 | 39 | **nuevo** (memoria G:) |
| **EA-1_3** | 299 | 1 | 215 | 32 | 33 | 19 | **nuevo** (un cilindro, ciego) |
| **EA-2_4** | 271 | 1 | 207 | 14 | 15 | 35 | **nuevo** (un cilindro, etiquetado a mano) |
| **Fluox-1(2)** | 299 | 1 | 214 | 4 | 48 | 33 | **nuevo** (un cilindro, ciego) |
| **fluox-2(2)** | 223 | 1 | 38 | 32 | 110 | 43 | **nuevo** (un cilindro, ciego) |
| **Total** | **8,248** | | 3,819 | 1,244 | 2,924 | 261 | |

- Se entrenan **7,025** segundos (nado, escalamiento e inmovilidad); los 131 de «activa» se guardan pero no se entrenan.
  El modelo actual se entrenó con 3,323.
- Las hojas nuevas son todas `humano_ciego` (etiquetadas desde cero, sin propuesta de la máquina).
- A `Acu-baihui1` se le descartaron 3 segundos (942 → 939): la hoja tiene más segundos de los que alcanza el video.

## De dónde salió

- `fuentes\etiquetas\`: las hojas `*_seg*.csv` de los 7 videos y sus `_rasgos.csv` y `_cuadros.csv`. **No se suben**; están para
  poder rehacer los clips. Las 4 hojas viejas vienen de `D:\proyectos\fst-etiquetador\etiquetas\`; las 3 nuevas
  (`Acu-baihui1_seg.csv`, `AcuYN1_seg.csv`, `IMG_0839_seg.csv`) vienen de la raíz de la memoria G:, copiadas y verificadas
  con SHA-256.
- Los clips se generaron con `cnn/recortar_seg.py` de `fst-etiquetador` sobre los videos de `H:\videos_sin_etiquetar`.
  Para rehacerlos:

  ```
  py cnn/recortar_seg.py --videos H:/videos_sin_etiquetar --etiquetas <esta carpeta>/fuentes/etiquetas --salida <esta carpeta>/fst/clips_seg --rehacer
  ```

Los videos **no** se copiaron aquí: Colab no los necesita (los clips ya traen la película de cada tubo).


## Avisos de esta versión

- `EA-2_4`: 28 segundos (186 a 260, en tramos sueltos) quedaron sin conducta y no entran; de 299 se usan 271. Sus hojas dicen
  `humano_corrige`/`humano_confirma` pero no hubo propuesta de la máquina (la columna `propuesta` está vacía): las etiquetas son del investigador.
- `fluox-2(2)` tiene 76 segundos sin conducta (no entran): de 299 solo se usan 223.
- Los videos de validación (`PCPA-FISIOL-5min`, `PCPA-Solfisiol-b`) NO están aquí y no deben estar en `clips_seg`.
- Hay poca escalamiento en `Fluox-1(2)` (4 s) y poco nado en `fluox-2(2)` (38 s): son videos desbalanceados.

- El código es `fst_cnn_seg` **0.3.0** (red `fst_cnn` 5.0.0) y el cuaderno es el de esa versión. Las secciones 1 a 7 hacen lo mismo que en 0.2.0
  (curva de pérdida en vivo y figuras en `Mi unidad/fst/figuras/`). La **sección 8** del cuaderno trae pruebas para subir la nota sin cambiar lo anterior:
  suavizado en el tiempo, modelo de transiciones, contexto de los segundos vecinos, menos épocas / más regularización / congelar capas, varias redes
  promediadas con volteo, entrenar sin los segundos de frontera y una tabla que compara todas las corridas (se guardan en `Mi unidad/fst/corridas/`).
  Cuaderno y `.py` deben ser de la misma versión.
  Con 25 ratas la celda de validar (sección 5) tarda más de una hora; si Colab se corta, usa `cada=2`.
