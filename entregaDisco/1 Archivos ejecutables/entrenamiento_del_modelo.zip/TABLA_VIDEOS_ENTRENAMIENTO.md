# Videos con los que se entrenó el modelo instalado

Modelo: fst_cnn_seg.pt, SHA-256 6d6f86ed419c2e58ce5044e49d6756148812f471b4927298bcf05ab56a2df95f, red fst_cnn 5.0.0, 15 épocas, entrenado en Colab el 16-nov-2026. Es el que se copió al VPS el 17-nov.

Fuente de los conteos: los 11 archivos .npz de `D:\proyectos\fst-entrenamiento-v3\fst\clips_seg\`, que son exactamente los datos con los que se entrenó. Se cuentan solo los segundos con nado, inmovilidad o escalamiento y con origen humano (a ciegas o corregido). No se cuentan los de conducta activa ni los que no tienen conducta.

## Tabla

| Video | Cilindros por video | Especímenes etiquetados | Nado | Inmovilidad | Escalamiento | Total de segundos |
|---|---|---|---|---|---|---|
| V01 | 3 | 3 | 420 | 349 | 122 | 891 |
| V02 | 3 | 3 | 415 | 344 | 170 | 929 |
| V03 | 3 | 2 | 285 | 213 | 81 | 579 |
| V04 | 4 | 1 | 151 | 139 | 79 | 369 |
| V05 | 4 | 4 | 441 | 826 | 179 | 1446 |
| V06 | 4 | 4 | 759 | 467 | 178 | 1404 |
| V07 | 4 | 4 | 674 | 380 | 353 | 1407 |
| V08 | 1 | 1 | 215 | 33 | 32 | 280 |
| V09 | 1 | 1 | 207 | 15 | 14 | 236 |
| V10 | 1 | 1 | 214 | 48 | 4 | 266 |
| V11 | 1 | 1 | 38 | 110 | 32 | 180 |
| Total | | 25 | 3819 | 2924 | 1244 | 7987 |

El total coincide con lo esperado: nado 3819, inmovilidad 2924, escalamiento 1244, suma 7987.

## Qué archivo es cada código y de dónde sale cada fila

Cada fila sale del archivo .npz del video (segundos, conducta y origen) y de su hoja de etiquetas. Las rutas son relativas a `D:\proyectos\fst-entrenamiento-v3\`.

```
V01  clips: fst\clips_seg\Acu-baihui1.npz     hoja: fuentes\etiquetas\Acu-baihui1_seg.csv
V02  clips: fst\clips_seg\Acu-YBN-2.npz       hoja: fuentes\etiquetas\Acu-YBN-2_seg.csv
V03  clips: fst\clips_seg\acu-yintang1.npz    hojas: fuentes\etiquetas\acu-yintang1_seg1.csv
                                                     fuentes\etiquetas\acu-yintang1_seg3.csv
V04  clips: fst\clips_seg\AcuBN1.npz          hoja: fuentes\etiquetas\AcuBN1_seg.csv
V05  clips: fst\clips_seg\AcuBN2.npz          hoja: fuentes\etiquetas\AcuBN2_seg.csv
V06  clips: fst\clips_seg\AcuYN1.npz          hoja: fuentes\etiquetas\AcuYN1_seg.csv
V07  clips: fst\clips_seg\IMG_0839.npz        hoja: fuentes\etiquetas\IMG_0839_seg.csv
V08  clips: fst\clips_seg\EA-1_3.npz          hoja: fuentes\etiquetas\EA-1_3_seg.csv
V09  clips: fst\clips_seg\EA-2_4.npz          hoja: fuentes\etiquetas\EA-2_4_seg.csv
V10  clips: fst\clips_seg\Fluox-1(2).npz      hoja: fuentes\etiquetas\Fluox-1(2)_seg.csv
V11  clips: fst\clips_seg\fluox-2(2).npz      hoja: fuentes\etiquetas\fluox-2(2)_seg.csv
```

Origen de las etiquetas contadas: V02 y V09 son de origen "humano_corrige"; los otros nueve son "humano_ciego".

## Lo que hay que saber de la tabla

1. Cilindros por video. La columna no es solo 1 o 4. En V01, V02 y V03 el etiquetador detectó 3 cilindros (sus tres recuadros salen en el archivo de rasgos), no 4. En V04 a V07 detectó 4 y en V08 a V11 se usó un solo cilindro. Si alguno de los tres videos con 3 cilindros en realidad tenía 4 y uno no se detectó, hay que revisarlo viendo el video; con lo que hay en los archivos, la cifra correcta es 3.

2. Especímenes etiquetados. V03 tiene 3 cilindros y solo 2 especímenes etiquetados (hojas seg1 y seg3). V04 tiene 4 cilindros y solo 1 espécimen etiquetado. El resto etiqueta todos sus cilindros.

3. Los 11 videos. Son los 11 .npz de `fst\clips_seg\`, que son los del modelo instalado. Si tu lista tiene 12, el que sobra es probablemente EA-1_1: tiene hoja de etiquetas (`G:\EA-1_1_seg.csv`) pero no entró al entrenamiento. Los videos de validación (PCPA-FISIOL-5min y PCPA-Solfisiol-b) no están entre los 11.

4. Diferencia con los segundos etiquetados. Los segundos que entraron a los .npz suman 8248. Los 261 de diferencia con los 7987 de la tabla son segundos de conducta activa (V01 48, V02 11, V03 6, V04 2, V05 2, V06 23, V07 39, V08 19, V09 35, V10 33, V11 43). Los segundos que no entraron a los .npz ni a ninguna cifra son los que la hoja trae sin conducta o sin revisar. Filas de la hoja y segundos que llegaron al .npz, por video: V01 951 y 939 (9 sin conducta y 3 que pasan del final del video), V02 960 y 940 (20 sin conducta), V03 1950 y 585 (dos hojas de 975 filas, con 1365 filas sin revisar o sin conducta), V04 1484 y 371 (1113 sin revisar), V05 1452 y 1448 (4 sin conducta), V06 1436 y 1427 (9 sin conducta), V07 1460 y 1446 (14 sin conducta), V08 299 y 299, V09 299 y 271 (28 sin conducta), V10 299 y 299, V11 299 y 223 (76 sin conducta).

5. Marcas [P]. Ninguna fila lleva [P]: el modelo instalado está fijo a estos datos y esta tabla no cambia mientras no se vuelva a entrenar. Se volvería [P] solo si se vuelve a entrenar con más videos (por ejemplo EA-1_1, EA-1_2, EA-1_4 y EA-2_1, que se están etiquetando) o si se completan los segundos "no se ve" de V09 y V11.

## Nombres originales de los videos

V01 Acu-baihui1, V02 Acu-YBN-2, V03 acu-yintang1, V04 AcuBN1, V05 AcuBN2, V06 AcuYN1, V07 IMG_0839, V08 EA-1_3, V09 EA-2_4, V10 Fluox-1(2), V11 fluox-2(2).
